function y = c(alpha)
y = (-0.5 * log(alpha)) .^ 0.5;
end