function x = invF(y, lambda)
x = - log(1 - y) / lambda;
end